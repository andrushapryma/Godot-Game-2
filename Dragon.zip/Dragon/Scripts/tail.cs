using Godot;
using System;

public partial class tail : Node2D
{
  
  float _radius = 100;
  float _speed = 11;
  float d = 0;
  bool _canRotate = true;
  bool _start = false;
  int tr = 2;
  
  public Color _color = new Color(255,255,255);


  Vector2 a = new Vector2();
  Vector2 p;

  // Called when the node enters the scene tree for the first time.
  public override void _Ready()
  {
    _radius = _radius * ( GetViewport().GetWindow().Size / new Vector2(540,1200)).Y;
    _start= false;
    p =GetViewport().GetWindow().Size/2 - GetCanvasTransform().Origin;
    GetNode<Global>("/root/Global")._score=0;
		 GetNode<Events>("/root/Events").EmitSignal("ChangeLevel", p);

    
  
    //GetNode<>("Marker2D/Trail2D")GetNode<Global>("/root/Global")._color;
    }
  private void _on_character_body_2d_area_entered(Area2D a)
  {
    if( a.Name == "Score")
    {
	//	p =GetViewport().GetWindow().Size/2 - GetCanvasTransform().Origin;
    GetNode<AudioStreamPlayer>("HitPlatform").Play();
    GetNode<Global>("/root/Global")._score+=1;
    tr =2;
    GetNode<Events>("/root/Events").EmitSignal("ShakeCamera", 5,0.25f);
    GetNode<Events>("/root/Events").EmitSignal("ChangeLevel", GlobalPosition);

    _canRotate = true;
    d = 0;
    _start = true;
   

    }

    else if(a.Name == "Obstacle" && _color != a.GetParent().GetParent<Obstacle>()._color && !_canRotate)
    {
      Fail();
      GD.Print("Tail Color is: " + _color);
      GD.Print("Obst Color is: " + a.GetParent().GetParent<Obstacle>()._color );
    //  GetParent().GetNode<Marker2D>("Marker2D").GetChild<Line2D>(0).DefaultColor = GetNode<Global>("/root/Global")._color;
    //  GetNode<Global>("/root/Global")._color = _color;
    }
  }
  private void Fail()
  {
    GetNode<Events>("/root/Events").EmitSignal("ShakeCamera", 20,0.25f);
    GetNode<Events>("/root/Events").EmitSignal("Fail", GlobalPosition);
    QueueFree();
  }

  // Called every frame. 'delta' is the elapsed time since the previous frame.
  public override void _Process(double delta)
  {
    if(_canRotate ) {

      d += -(float)delta;
      }
    
    
    if(_start && !_canRotate  )
    {
      GlobalPosition += a * _speed * 200  *(float)delta;
      

        p = GlobalPosition;
      

    }
    if(_canRotate && _start)
    {
      //Position = GetGlobalMousePosition();
      Position = new Vector2 (Mathf.Sin(d * _speed)* _radius, Mathf.Cos(d * _speed) * _radius)+ p;

    }
   
    
   }
      public override void _Input(InputEvent @event)
    {
        if(@event is InputEventScreenTouch touch)
    {
      if(tr >0)
      {
      _start = true;
      _canRotate = true;
      _speed = BoolToSign( tr==2) * _speed;

      GetNode<AudioStreamPlayer>("Rotate").Play();
      }


      if(_start && touch.IsPressed() == false && tr >0 && _canRotate)
      {
        
        a= BoolToSign( tr==2)*  (GlobalPosition - p).Rotated(Mathf.Pi/2 ) ;
        a = a.Normalized();
        d = 0;
        tr -=1;
        GetNode<AudioStreamPlayer>("Move").Play();
        _canRotate = false;

      }  
    }
    }
  private int BoolToSign(bool value)
  {
    if(value){
      return 1;
    }
    if(!value)
    {
      return -1;
    }
    return 0;
  }

  private void _on_visible_on_screen_notifier_2d_screen_exited()
  {
    Fail();
  }
}