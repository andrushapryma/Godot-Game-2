using Godot;
using System;

public partial class Obstacle : Node2D
{
	public Color _color;
	public	 Vector2 _dir;
	// Called when the node enters the scene tree for the first time.
	public override void _Ready()
	{
		_color =GetNode<Global>("/root/Global").GenerateColor();
		GetNode<ColorRect>("ColorRect").Color = _color;

	}

	// Called every frame. 'delta' is the elapsed time since the previous frame.
	public override void _Process(double delta)
	{
		MoveLocalY(_dir.Y*(float)delta * 90);
		MoveLocalX(_dir.X * (float)delta * 90);
	}
	private void _on_visible_on_screen_notifier_2d_screen_exited()
	{
		QueueFree();
	}
}
