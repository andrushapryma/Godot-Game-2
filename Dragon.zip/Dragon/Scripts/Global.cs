using Godot;
using System.Collections.Generic;
public partial class Global : Node
{
	public int _score;
	List<Color> _colors = new List<Color>();
	public int _bestScore = 0;
	public override void _Ready()
	{

		_colors.Add(new Color("51ffff"));
		_colors.Add(new Color("d887e5"));
		_colors.Add(new Color("f74d3a"));
		_colors.Add(new Color("f2c641"));
		_colors.Add(new Color("63e8ac"));
		_colors.Add(new Color("9bd3f9"));
		_score = 0;
	}
	public override void _Process(double delta)
	{
	}
	public Color GenerateColor()
	{
		var _rng = new RandomNumberGenerator();
		_rng.Randomize();
		var c =  _colors[_rng.RandiRange(0,_colors.Count-1)];
		_rng.Dispose();
		return c;
	}
}