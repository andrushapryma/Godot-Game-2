using Godot;
using System;
public partial class Platform : PathFollow2D
{
	public Color _color;
	public Vector2 _scale = new Vector2(5,5);

	public override void _Ready()
	{
		GD.Print(GetNode<Global>("/root/Global")._score);
		ProgressRatio = GetRatio();
		_color = GetNode<Global>("/root/Global").GenerateColor();
		GetNode<ColorRect>("Score/CollisionShape2D/ColorRect").Color = _color;

	}
	public override void _Process(double delta)
	{

	}
	public float GetRatio()
	{	
		var _rng = new RandomNumberGenerator();	
		_rng.Randomize();
		var a = _rng.RandfRange(0,1);
		while(a <=0.25f || a >=0.8f)
		{
			_rng.Randomize();
			 a = _rng.RandfRange(0,1);
		}
		_rng.Dispose();
		return a;
	}

}