using Godot;
using System;
using System.Linq;

public partial class WindowOptimiz : Node2D
{
	[Export] NodePath _path;
	[Export] NodePath _right;
	[Export] NodePath _left;
	[Export] NodePath _top;
	[Export] NodePath _bottom;
	Vector2[] _p = new Vector2[4];
	float _scale = 600;
	
 	// Called when the node enters the scene tree for the first time.
	public override void _Ready()
	{
		var b = 
		GetCanvasTransform().Origin;
				var w =GetViewport().GetWindow().Size.X;
	GD.Print(b);
		var h = GetViewport().GetWindow().Size.Y;
		GetNode<Path2D>(_path).Curve.AddPoint(new Vector2(-b.X,-b.Y   ) )                 ; // 0,0
		GetNode<Path2D>(_path).Curve.AddPoint(new Vector2(-b.X,h-b.Y)  )  ; // 0,1
		GetNode<Path2D>(_path).Curve.AddPoint(new Vector2(w-b.X,h-b.Y)   )  ; // 1,1
		GetNode<Path2D>(_path).Curve.AddPoint(new Vector2(w-b.X-0,0-b.Y)   )  ; //1,0
		GetNode<Path2D>(_path).Curve.AddPoint(new Vector2(0-b.X,0-b.Y	)     )  ; //0,0
	

		//GetNode<Path2D>(_path).Curve.ClearPoints() ;
		//GetNode<MarginContainer>(_l).AddThemeConstantOverride("margin_left",w-120);

	
	}


}
