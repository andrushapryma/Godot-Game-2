using Godot;
using System;

public partial class PlatformSpawner : Node2D
{
	string _path = "res://Platform.tscn";
	string _ob = "res://Obstacle.tscn";
	Vector2 _scale = new Vector2(1,1);
	[Export] NodePath _pathFollow;
	Vector2 b;
	public Platform p;
	int w;
	int h;
	public override void _Ready()
	{
		p = GD.Load<PackedScene>(_path).Instantiate<Platform>();
		GetNode<Path2D>(_pathFollow).CallDeferred("add_child",p);
		p.Scale =  p._scale * GetViewport().GetWindow().Size / new Vector2(540,1200) ;
		GetNode<Events>("/root/Events").Connect("ChangeLevel", new Callable(this, "ChangeLevel"));
		ChangeLevel(new Vector2(GetViewport().GetWindow().Size.X/2,GetViewport().GetWindow().Size.Y/2));
		var a =  Mathf.Clamp( GetViewport().GetWindow().Size.Length() / new Vector2(646,1152).Length() * 1, 1, 20);
		_scale = new Vector2(a,a);
		
		w = GetViewport().GetWindow().Size.X;
	GD.Print(b);
		h = GetViewport().GetWindow().Size.Y;
	
	
	
	}
	


	public override void _Process(double delta)
	{
	}
	private void ChangeLevel( Vector2 pos)
	{

		
		if(GetChild<Timer>(0).WaitTime >0.5f)
		GetChild<Timer>(0).WaitTime-=  0.1f;
		GetChild<Timer>(0).WaitTime = Mathf.Clamp(GetChild<Timer>(0).WaitTime,1,3);
		_scale -= new Vector2(0.025f,0.025f);
		_scale.X = Mathf.Clamp( _scale.X, 0.3f, 1f);
		_scale.Y = Mathf.Clamp( _scale.Y, 0.3f, 1f);
		p.Scale = _scale;
		p.ProgressRatio = p.GetRatio();
		
	
	}
	private void _on_timer_timeout()
	{

		var b = 
		GetCanvasTransform().Origin;
				var w =GetViewport().GetWindow().Size.X;
	GD.Print(b);
		var h = GetViewport().GetWindow().Size.Y;
		var a = GD.Load<PackedScene>(_ob).Instantiate<Obstacle>();
		GetParent().AddChild(a);
		a.GlobalPosition = GetPos(w- (int)b.X, h- (int)b.Y);
		a._dir = GetViewport().GetWindow().Size/2 - GetCanvasTransform().Origin - a.GlobalPosition;
		a._dir = a._dir.Normalized();
	}

	    private Vector2 GetPos(int rectWidth, int rectHeight)
    {
		RandomNumberGenerator _rng = new RandomNumberGenerator();
		_rng.Randomize	();
		var _pos = new Vector2();
		int n = _rng.RandiRange(0,3);
		switch (n) {
			case 0:
				_pos = new Vector2(rectWidth, rectHeight);break;
			case 1:
			_pos = new Vector2(0, rectHeight); break;
			case 2:
				_pos = new Vector2(0, 0); break;
			case 3:
				_pos = new Vector2(rectWidth, 0); break;

		}
		return _pos;
	}
}
