using Godot;
using System;
using System.Collections.Generic;
public partial class MainScene : Node
{
	tail Tail;

	List<Color> _colors = new List<Color>();
	Marker2D _marker;
	public override void _Ready()
	{	Tail = GetNode<tail>("TailCollider");

		 GetNode<Events>("/root/Events").Connect("ChangeLevel",new Callable(this, "ChangeLevel"));
		 GetNode<Events>("/root/Events").Connect("Fail",new Callable(this, "OnFail"));
		 _marker = GetNode<Marker2D>("Marker2D");
		GetNode<Line2D>("Trail2D").Width = (GetViewport().GetWindow().Size / new Vector2(540,1200)).Y * 55;
       		 GetNode<Events>("/root/Events").EmitSignal("ShakeCamera",0.1f,0.1f);
		 GetNode<AnimationPlayer>("AnimationPlayer").Play("hide");
		
	}


 
    public override void _Process(double delta)
	{if(IsInstanceValid(Tail))
		_marker.GlobalPosition = Tail.GlobalPosition;
	}
	private void ChangeLevel( Vector2 pos)
	{
		 var _explosion = GD.Load<PackedScene>("res://exp.tscn").Instantiate<GpuParticles2D>();

		GetNode<Line2D>("Trail2D").DefaultColor =  GetNode<PlatformSpawner>("PlatformSpawner").p.GetNode<ColorRect>("Score/CollisionShape2D/ColorRect").Color;
		GetNode<tail>("TailCollider")._color = GetNode<Line2D>("Trail2D").DefaultColor;
		GetNode<PlatformSpawner>("PlatformSpawner").p.GetNode<ColorRect>("Score/CollisionShape2D/ColorRect").Color=GetNode<Global>("/root/Global").GenerateColor() ;
		
		((ParticleProcessMaterial) _explosion.ProcessMaterial).Color = GetNode<Line2D>("Trail2D").DefaultColor;
		 

		_explosion.Emitting = true;
		AddChild(_explosion);
		_explosion.GlobalPosition = pos;
		GetNode<Label>("CanvasLayer/Score/VBoxContainer/HBoxContainer/Label").Text = GetNode<Global>("/root/Global")._score.ToString();
	}
	private void OnFail(Vector2 pos)
	{
		var b = GD.Load<PackedScene>("res://exp.tscn").Instantiate<GpuParticles2D>();
		((ParticleProcessMaterial) b.ProcessMaterial).Color = GetNode<Line2D>("Trail2D").DefaultColor;
		
		b.Emitting = true;
		AddChild(b);
		b.GlobalPosition = pos;
		b.Scale *=100;
		GetNode<MarginContainer>("CanvasLayer/Score").Hide();
		GetNode<Node2D>("Marker2D").Hide();
		GetNode<Timer>("Timer").Start();
		GetNode<Control>("CanvasLayer/Menu").Show();
		GetNode<AudioStreamPlayer>("Fail").Play();
		if(GetNode<Global>("/root/Global")._bestScore < GetNode<Global>("/root/Global")._score)
		{
		GetNode<Global>("/root/Global")._bestScore =GetNode<Global>("/root/Global"). _score;
		}
		GetNode<Label>("CanvasLayer/Menu/TryAgain/VBoxContainer/HBoxContainer2/Label").Text = "best score:" + GetNode<Global>("/root/Global")._bestScore.ToString() ;

	}
	private void _on_button_button_up()
	{
		GetTree().ReloadCurrentScene();
	}
	private void OnQuit()
	{
		GetTree().Quit();
	}

}
