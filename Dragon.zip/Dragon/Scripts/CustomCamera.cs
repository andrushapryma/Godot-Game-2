using Godot;
using System;

public partial class CustomCamera : Camera2D
{
    private float shakeIntensity = 0f; // The amount of shake
    private Random random = new Random(); // Random number generator for shake

    // Call this method to initiate screen shake
    public void StartShake(float intensity, float duration)
    {
        shakeIntensity = intensity;
        Timer shakeTimer = new Timer();
        AddChild(shakeTimer);
        shakeTimer.WaitTime = duration;
        shakeTimer.OneShot = true;
        shakeTimer.Connect("timeout", new Callable(this, "StopShake"));
        shakeTimer.Start();

    }
    public override void _Ready()
    {
       GetNode<Events>("/root/Events").Connect("ShakeCamera",new Callable(this, "StartShake"));
       AnchorMode = AnchorModeEnum.DragCenter;
       
    }

    public override void _Process(double delta)
    {
    
        if (shakeIntensity > 0)
        {
            float offsetX = (float)(random.NextDouble() * 2 - 1) * shakeIntensity;
            float offsetY = (float)(random.NextDouble() * 2 - 1) * shakeIntensity;
            Offset = new Vector2(offsetX, offsetY);
        }
    }

    private void StopShake()
    {
        shakeIntensity = 0f;
        Offset = Vector2.Zero; // Reset the camera's offset to its original position
    } 
     
}