using Godot;
public partial class Events : Node
{
	[Signal] public delegate void ShakeCameraEventHandler(float power, float duration);
	[Signal] public delegate void ChangeLevelEventHandler(Vector2 pos);
	[Signal] public delegate void FailEventHandler(Vector2 pos);
}