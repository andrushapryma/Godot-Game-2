
using Godot;
using System;

public partial class Dragon : Sprite2D
{
	double d;
	bool _canRotate = false;
	float _speed = 1.001f;
	// Called when the node enters the scene tree for the first time.
	public override void _Ready()
	{
		
	}
	

	// Called every frame. 'delta' is the elapsed time since the previous frame.
	public override void _Process(double delta)
	{
		if(_canRotate)
		{
			Rotate(-(float)d);
			d+= (float)delta/10;
			GlobalPosition += new Vector2(10,0);
			d= Mathf.Clamp(d,delta,delta*10);
		//	s = ToGlobal(new Vector2(1,1));
			
		}
		else{
			d = 0;
		}
		
	}
    public override void _Input(InputEvent @event)
    {
        if(@event is InputEventScreenTouch touch)
		{
			_canRotate = touch.IsPressed() ;
			touch.Dispose();
		}
		
    }
}
